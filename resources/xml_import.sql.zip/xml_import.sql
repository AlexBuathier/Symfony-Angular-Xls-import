SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE `city` (
  `id` int NOT NULL,
  `country_id` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `city` (`id`, `country_id`, `name`) VALUES
(1, 1, 'Paris'),
(2, 1, 'Bordeaux'),
(3, 1, 'Lyon'),
(4, 2, 'Berlin'),
(5, 2, 'Munich'),
(6, 2, 'Frankfurt'),
(7, 3, 'Madrid'),
(8, 3, 'Barcelona'),
(9, 3, 'Valencia'),
(10, 4, 'Rome'),
(11, 4, 'Milan'),
(12, 4, 'Venice'),
(13, 5, 'Londres'),
(14, 5, 'Basildon'),
(15, 5, 'Bristol'),
(16, 5, 'Liverpool'),
(17, 6, 'New York'),
(18, 6, 'Aberdeen'),
(19, 6, 'Los Angeles');

CREATE TABLE `country` (
  `id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `country` (`id`, `name`) VALUES
(1, 'France'),
(2, 'Germany'),
(3, 'Spain'),
(4, 'Italy'),
(5, 'Royaume-Uni'),
(6, 'Etats-unis');

CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;

INSERT INTO `doctrine_migration_versions` (`version`, `executed_at`, `execution_time`) VALUES
('DoctrineMigrations\\Version20220630075306', '2022-07-05 21:30:06', 22),
('DoctrineMigrations\\Version20220630075837', '2022-07-05 21:30:06', 72),
('DoctrineMigrations\\Version20220701064745', '2022-07-05 21:30:06', 23),
('DoctrineMigrations\\Version20220701065323', '2022-07-05 21:30:06', 24),
('DoctrineMigrations\\Version20220701071031', '2022-07-05 21:30:06', 81),
('DoctrineMigrations\\Version20220701075213', '2022-07-05 21:30:06', 194),
('DoctrineMigrations\\Version20220701075518', '2022-07-05 21:30:06', 28);

CREATE TABLE `music_group` (
  `id` int NOT NULL,
  `start_date` date NOT NULL,
  `separation_date` date DEFAULT NULL,
  `founder` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `members` int DEFAULT NULL,
  `presentation` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `music_trend_id` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `music_group` (`id`, `start_date`, `separation_date`, `founder`, `members`, `presentation`, `music_trend_id`, `name`, `city_id`) VALUES
(1, '1979-01-01', '1982-01-01', '1John Doe', 6, '1Lorem ipsum dolor, nisl nisi consectetur nisl, euismod euismod \n                 nisi nisi euismod nisi. Donec euismod', 1, '1 groupe name', 5),
(2, '1978-01-01', '1984-01-01', '2John Doe', 2, '2Lorem ipsum dolor, nisl nisi consectetur nisl, euismod euismod \n                 nisi nisi euismod nisi. Donec euismod', 2, '2 groupe name', 1),
(3, '1977-01-01', '1986-01-01', '3John Doe', 6, '3Lorem ipsum dolor, nisl nisi consectetur nisl, euismod euismod \n                 nisi nisi euismod nisi. Donec euismod', 5, '3 groupe name', 1),
(4, '1976-01-01', '1988-01-01', '4John Doe', 4, '4Lorem ipsum dolor, nisl nisi consectetur nisl, euismod euismod \n                 nisi nisi euismod nisi. Donec euismod', 1, '4 groupe name', 4),
(5, '1975-01-01', '1990-01-01', '5John Doe', 5, '5Lorem ipsum dolor, nisl nisi consectetur nisl, euismod euismod \n                 nisi nisi euismod nisi. Donec euismod', 3, '5 groupe name', 5);

CREATE TABLE `music_trend` (
  `id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `music_trend` (`id`, `name`) VALUES
(1, 'Pop rock'),
(2, 'Rock'),
(3, 'Grunge'),
(4, 'Trip hop'),
(5, 'Other');


ALTER TABLE `city`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_2D5B0234F92F3E70` (`country_id`);

ALTER TABLE `country`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `doctrine_migration_versions`
  ADD PRIMARY KEY (`version`);

ALTER TABLE `music_group`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_A493F0DA2A3F694` (`music_trend_id`),
  ADD KEY `IDX_A493F0D8BAC62AF` (`city_id`);

ALTER TABLE `music_trend`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `city`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

ALTER TABLE `country`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

ALTER TABLE `music_group`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

ALTER TABLE `music_trend`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;


ALTER TABLE `city`
  ADD CONSTRAINT `FK_2D5B0234F92F3E70` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`);

ALTER TABLE `music_group`
  ADD CONSTRAINT `FK_A493F0D8BAC62AF` FOREIGN KEY (`city_id`) REFERENCES `city` (`id`),
  ADD CONSTRAINT `FK_A493F0DA2A3F694` FOREIGN KEY (`music_trend_id`) REFERENCES `music_trend` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
